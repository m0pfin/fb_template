<?php
/**
 * Created by PhpStorm.
 * User: m0pfin
 * Date: 11.07.2020
 * Time: 19:20
 */

return [
    'host' => 'localhost',
    'db_name' => 'template', // Имя базы данных
    'user' => 'root', // Юзер базы данных
    'password' => 'root', // Пароль базы данных
    'charset' => 'utf8'
];